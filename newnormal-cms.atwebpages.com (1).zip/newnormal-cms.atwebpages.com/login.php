<?php
//here,'u_type' means usertype{customer,shopkeeeper}
include("header.php");
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true)
{
header('location:welcome.php');
}
?>
<div class="py-5 text-center" style="" >
    <div class="container">
      <div class="row">
        <div class="mx-auto col-md-6 col-10 bg-white p-5">
          <h1 class="mb-4">Log in</h1>
 <form action="" method="post">
   <div class="form-group">
   <input type="text" name="uid" placeholder="user id" class="form-control" required>
    <br>
  </div>
   <div class="form-group mb-3">
   <input type="password" name="upass" placeholder="password" class="form-control" required>
    <br>
  </div>
   
   <div class="form-group mb-3">
   
   <p>Please select user type:</p>
   
   <input type="radio" name="usertype" value="Customer" required>Customer
    <br>
   
   <input type="radio" name="usertype" value="Shopkeeper">Shopkeeper
    <br>

  </div>
    <small class="form-text text-muted text-right">
      <a href="#"> Recover password</a>
    </small>
   
   <input type="submit" name="hsubmit" class="btn btn-primary" value="Login">
    <br>
 
 </form>
        </div>
      </div>
    </div>
  </div>

<?php
  if(isset($_POST['hsubmit']))
  {
  	 $userid=$_POST['uid'];
  	 $pwd=$_POST['upass'];    
  	 $user_type=$_POST['usertype'];
  	 $user_type=strtolower($user_type);
  	 if($user_type=="customer")
  	 {
   	  	$query="SELECT * FROM customer WHERE c_id='$userid' && c_pass='$pwd' ";
    		$ut="customer";
  	 }
  	 else
  	 {
  	  	$query="SELECT * FROM shop WHERE shop_id='$userid' && shop_password='$pwd' ";
    		$ut="shopkeeper";
  	 }
    $data=mysqli_query($fetchdata->con,$query);
    $total=mysqli_num_rows($data);
     if($total==1)
      {
      	if($ut=="customer")
      	{
      		$squery="SELECT c_name,c_id FROM customer WHERE c_id='$userid' ";
            $data=mysqli_query($fetchdata->con,$squery);
            $result=mysqli_fetch_assoc($data);
            $_SESSION['user_name']=$result['c_name'];
            $_SESSION['loggedin'] = true;
            $_SESSION['u_type']="customer";
            $_SESSION['login_u_id']=$result['c_id']; //$login_u_id is the logged in user id
            header('location:welcome.php');
      	}
      	else if($ut=="shopkeeper")
      	{
      		$squery="SELECT * FROM shop WHERE shop_id='$userid' ";
            $data=mysqli_query($fetchdata->con,$squery);
            $result=mysqli_fetch_assoc($data);
            $_SESSION['user_name']=$result['shop_owner'];
            $_SESSION['loggedin'] = true;
            $_SESSION['sid']=$result['shop_id'];
            $_SESSION['u_type']="shopkeeper";
            $_SESSION['login_u_id']=$result['shop_id']; //$login_u_id is the logged in user id
            header('location:welcome.php');	
      	}
      	else
      	{
      		echo  " ".mysqli_error($fetchdata->con);
      	}
      }
     else
      {
      	echo "<script>alert('User ID or password is incorrect!');</script>";
      } 
  }

  include("footer.php");

?>