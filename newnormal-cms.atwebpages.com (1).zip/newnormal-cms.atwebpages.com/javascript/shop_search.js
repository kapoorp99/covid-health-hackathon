//qs() is a function for searching the query
//sq is the search query which is passed to php page
//noqs() is same as qs but do not use ajax
var x;
/*
function qs()
{
	if( $("#query").val())
	{
		x=$("#query").val();
		$.ajax({
			method: 'POST',
			url: "search_shops.php",
			data: {sq:x},
			dataType: "text",
			success: function(res)
			{
				$("#results_tab").text(res);
			},
			error: function(err)
			{
				console.log(err);
			}
		});
	}
	else
	{
		alert("enter shop id in search bar");
	}
}
*/
function noqs()
{
	if( $("#query").val())
	{
		x=$("#query").val();
		window.location.href="search_results.php?sq="+x;
	}
	else
	{
		alert("enter shop id in search bar");
	}
}