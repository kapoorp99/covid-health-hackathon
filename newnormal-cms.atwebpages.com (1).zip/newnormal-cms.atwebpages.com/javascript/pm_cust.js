//this js will increase or decrease customers present at shop

var dec;
var inc;
$(document).ready(function(){
$('#minus').click(function(){
 if ($('#label').text() == 0) 
 {
    alert("Less than 0 not allowed")
 }
 else
 {
    dec = $('#label').text();
    dec = dec - 1;
    decdb();
    $('#label').text(dec);
 }
});
$('#plus').click(function(){
    inc = $('label').text();
    inc = Number(inc) + 1;
    inc = inc.toString();
    incdb();
    $('#label').text(inc);
});
});


function incdb()
{

    $("#i").ready(function(){
                $.ajax({
                    method: 'POST',
                    url: "customer_counter.php",
                    data: {cust_i:inc},
                    dataType: "text",
                    success: function(res)
                    {
                        $("#btn_value").text(res);
                    },
                    error: function(err)
                    {
                        console.log(err);
                    }
                });
            });
}
function decdb()
{

    $("#d").ready(function(){
                $.ajax({
                    method: 'POST',
                    url: "customer_counter.php",
                    data: {cust_d:dec},
                    dataType: "text",
                    success: function(res)
                    {
                        $("#btn_value").text(res);
                    },
                    error: function(err)
                    {
                        console.log(err);
                    }
                });
            });
}
        