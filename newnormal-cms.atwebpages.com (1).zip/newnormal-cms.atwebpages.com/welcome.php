<?php
include("welcome_header.php");
$fetchdata=new DB_con;
?>

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">

var x;
function noqs()
{
	if( $("#query").val())
	{
		x=$("#query").val();
		window.location.href="search_results.php?sq="+x;
	}
	else
	{
		alert("enter shop id in search bar");
	}
}
</script>




<?php
if(!(isset($_SESSION['user_name']) && $_SESSION['user_name']!=""))
{
  header('location:login.php');
}

        $usertype=$_SESSION['u_type'];
        if($usertype=="shopkeeper")
        {
          $id_of_shop=$_SESSION['sid'];
          $sql_query="SELECT * FROM shop_status WHERE shop_id='$id_of_shop' ";
          $data=mysqli_query($fetchdata->con,$sql_query);
          $result=mysqli_fetch_assoc($data);
          $temp=$result['status'];
?>


<?php 
if(isset($_POST['toggle_status_php']))
{
  $hf=$_POST['name_hidden_toggle']; //value of hidden field

  if($hf=="Open Shop")
  {
    $ch="open";
  }
  else if($hf=="Close Shop")
  {
    $ch="close";
  }

  $update_in_db_query="UPDATE shop_status SET status='$ch' WHERE shop_id='$id_of_shop' ";
  $update_execute=mysqli_query($fetchdata->con,$update_in_db_query);
  $changeonpage="SELECT * FROM shop_status WHERE shop_id='$id_of_shop' ";
  $changeonpage_exe=mysqli_query($fetchdata->con,$changeonpage);
  $result=mysqli_fetch_assoc($changeonpage_exe);
  $temp=$result['status'];
}

$id_of_shop=$_SESSION['sid'];
if(isset($_POST['cust_i']))
{
	$x=$_POST['cust_i'];
	 $num_cust_sql="UPDATE customer_at_shop SET num_of_cust='$x' WHERE shop_id='$id_of_shop' ";
	 $data=mysqli_query($fetchdata->con,$num_cust_sql);
	echo $x;
}
if(isset($_POST['cust_d']))
{
	$y=$_POST['cust_d'];
	$num_cust_sql="UPDATE customer_at_shop SET num_of_cust='$y' WHERE shop_id='$id_of_shop' ";
	$data=mysqli_query($fetchdata->con,$num_cust_sql);
	echo $y;
}
?>
<script type="text/javascript"> window.CSRF_TOKEN = "{{ csrf_token }}"; </script>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.js"></script>
  <script>
var dec;
var inc;
$(document).ready(function(){
$('#minus').click(function(){
 if ($('#label').text() == 0) 
 {
    alert("Less than 0 not allowed")
 }
 else
 {
    dec = $('#label').text();
    dec = dec - 1;
    decdb();
    $('#label').text(dec);
 }
});
$('#plus').click(function(){
    inc = $('label').text();
    inc = Number(inc) + 1;
    inc = inc.toString();
    incdb();
    $('#label').text(inc);
});
});


function incdb()
{

    $("#i").ready(function(){
                $.ajax({
                    method: 'POST',
                    data: {cust_i:inc, "csrfmiddlewaretoken" : "{{csrf_token}}"},
                    dataType: "text",
                    success: function(res)
                    {
                        $("#btn_value").text(res);
                    },
                    error: function(err)
                    {
                        console.log(err);
                    }
                });
            });
}
function decdb()
{

    $("#d").ready(function(){
                $.ajax({
                    method: 'POST',
                    data: {cust_d:dec, "csrfmiddlewaretoken" : "{{csrf_token}}"},
                    dataType: "text",
                    success: function(res)
                    {
                        $("#btn_value").text(res);
                    },
                    error: function(err)
                    {
                        console.log(err);
                    }
                });
            });
}
        
  </script>
    <div class="py-5 text-center" >
    <div class="container">
      <div class="row">
        <div class="mx-auto col-lg-5 col-md-7 col-10">
          <h1>Number of cutomers at shop:</h1>
          <label id="label">0</label>
          <button class="btn btn-primary mr-3" id="plus">Increase</button>
          <button class="btn btn-primary mr-3" id="minus">Decrease</button>
        </div>
      </div>
    </div>
    </div>
<div class="py-5 text-center" >
  <div class="container">
      <div class="row">
        <div class="col-md-9 p-3">
          <h1 class="mb-0">Shop is <?php echo $temp."."; ?></h1>
        </div>
        <div class="col-md-3 align-items-center d-flex justify-content-center p-3"> 

           <form action="" method="POST"> 
            <input type="hidden" name="name_hidden_toggle" id="hidden_toggle">
            <input type="submit" name="toggle_status_php" onclick="shop_oc()" id="toggle_status_id" class="btn btn-primary btn-lg" value="<?php if($temp=="close"){echo "Open";}else{echo "Close";} ?> Shop">
           </form>


        </div>
      </div>
    </div>
</div>


<script>
 function shop_oc()
  {
    var x=$("#toggle_status_id").val();
    document.getElementById("hidden_toggle").value = x;
  }
</script>

<?php
}
else if($usertype=="customer")
{
?>



<!--search bar-->

<nav class="navbar navbar-expand-md navbar-dark bg-primary">
    <div class="d-flex flex-grow-1">
        <form class="mr-2 my-auto w-100 d-inline-block order-1">
            <div class="input-group">
                <input type="text" class="form-control border border-right-0" placeholder="Search shops....." id="query">
                <span class="input-group-append">
                    <button class="btn btn-outline-light border border-left-0" type="button" onclick="noqs()">
                        <i class="fa fa-search"></i>
                    </button>
                </span>
            </div>
        </form>
    </div>
</nav>

<!--/search bar-->

<?php 
//here we code to show data in the table
$i=0;
$f_shopid_arr=null; //it contains id of shops followed by the customer
$id_of_cust=$_SESSION['login_u_id'];
$sfbc_sql="SELECT * FROM customer_follows WHERE cust_id='$id_of_cust' "; //$sfbc => shops_followed_by_cust
$exe_sfbc_sql=mysqli_query($fetchdata->con,$sfbc_sql);
$num_of_sf=mysqli_num_rows($exe_sfbc_sql); //$num_of_sf => number of shops followed
echo "number of followed shops=$num_of_sf";
while( $fetched_data = mysqli_fetch_assoc($exe_sfbc_sql) )
{
  $f_shopid_arr[$i]=$fetched_data['shop_id'];
  $i++;
}



echo '<!-- table started -->

<div class="container">
  <h5>Information of shops you follow:</h5>
  <br>            
  <table class="table">
    <thead>
      <tr>
        <th>Shop Name</th>
        <th>Shop status</th>
        <th>Number of Customers</th>
      </tr>
    </thead>';




for ($i=0; $i < $num_of_sf ; $i++) 
{

  if($f_shopid_arr!=null)
    {
      $d1_sql="SELECT shop_name FROM shop WHERE shop_id='$f_shopid_arr[$i]' ";
      $exe_d1_sql=mysqli_query($fetchdata->con,$d1_sql);
      $info1=mysqli_fetch_assoc($exe_d1_sql);
      $r1=$info1['shop_name'];
      $d2_sql="SELECT status FROM shop_status WHERE shop_id='$f_shopid_arr[$i]' ";
      $exe_d2_sql=mysqli_query($fetchdata->con,$d2_sql);
      $info2=mysqli_fetch_assoc($exe_d2_sql);
      $r2=$info2['status'];
      $d3_sql="SELECT num_of_cust FROM customer_at_shop WHERE shop_id='$f_shopid_arr[$i]' ";
      $exe_d3_sql=mysqli_query($fetchdata->con,$d3_sql);
      $info3=mysqli_fetch_assoc($exe_d3_sql);
      $r3=$info3['num_of_cust'];
      $output_in_table='<tbody>
      <tr>
        <td>'.$r1.'</td>
        <td>'.$r2.'</td>
        <td>'.$r3.'</td>
      </tr>'; //shows output in table
      echo $output_in_table;

?>



    
  


<!-- table ended -->



<?php 
}
}
?>



<?php
echo '</tbody></table>
</div>';
}
?>
<?php
  include("welcome_footer.php");
?>