<?php
session_start();
define('DB_SERVER','fdb23.awardspace.net');
define('DB_USER','3421666_cms');
define('DB_PASS','D882APK@uYfaPNy');
define('DB_NAME','3421666_cms');
class DB_con
{
public $con;
public function __construct()
 {
   $this->con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
    if (mysqli_connect_errno())
    {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
 } 
}
?>

