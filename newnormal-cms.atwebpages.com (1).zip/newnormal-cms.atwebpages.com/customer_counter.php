<?php
ob_start();
include ("config/connection.php");
$fetchdata=new DB_con;
$id_of_shop=$_SESSION['sid'];
if(isset($_POST['cust_i']))
{
	$x=$_POST['cust_i'];
	 $num_cust_sql="UPDATE customer_at_shop SET num_of_cust='$x' WHERE shop_id='$id_of_shop' ";
	 $data=mysqli_query($fetchdata->con,$num_cust_sql);
	echo $x;
}
if(isset($_POST['cust_d']))
{
	$y=$_POST['cust_d'];
	$num_cust_sql="UPDATE customer_at_shop SET num_of_cust='$y' WHERE shop_id='$id_of_shop' ";
	$data=mysqli_query($fetchdata->con,$num_cust_sql);
	echo $y;
}
ob_end_flush();
?>