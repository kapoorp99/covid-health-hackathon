<?php 
include_once("config/connection.php");
$fetchdata=new DB_con;
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true)
{
    header('location:welcome.php');
}
?>
<?php
 include("header.php");
?>
<div class="container bg-info">
<p class="font-weight-bold">
<?php
if(isset($_POST['hsubmit']))
{
  $cname=$_POST['hcust_name'];
  $cpass=$_POST['hcust_password'];
  $cphone=$_POST['hcust_contact'];
    $isql="INSERT INTO customer (c_name,c_pass,c_contact) VALUES('$cname','$cpass','$cphone')";
    $d=mysqli_query($fetchdata->con,$isql);

      if($d)
      {
        echo "Data inserted successfully.";
        $last_ins_id=mysqli_query($fetchdata->con,"SELECT * FROM customer WHERE c_id=(last_insert_id()) "); //last inserted customer id
        $res_last_ins_id=mysqli_fetch_assoc($last_ins_id);
        $temp_res_last_ins_id=$res_last_ins_id['c_id'];
        echo " Your login ID: ".$temp_res_last_ins_id;
        $image_base64 = base64_encode(file_get_contents('default_image/default_user_pic.jpg'));
        $image = 'data:image/jpg;base64,'.$image_base64;
        $img_ins_sql="INSERT INTO images (uid,image) VALUES('$temp_res_last_ins_id','$image')" ; //default image insertion
        $exe_img_ins_sql=mysqli_query($fetchdata->con,$img_ins_sql);
      }  
      else
      {
        echo "Data is not inserted.".mysqli_error($fetchdata->con);
      } 

}

?>
</p>
</div>

<div class="py-5 text-center" style="" >
    <div class="container">
      <div class="row">
        <div class="mx-auto col-md-6 col-10 bg-white p-5">
          <h1 class="mb-4">Register new customer</h1>

<form action="" method="post">
	<div class="form-group">
	<input type="text" name="hcust_name" placeholder="Customer Name" class="form-control" required>
	<br>
    </div>
    <div class="form-group">
	<input type="password" name="hcust_password" placeholder="Customer Password" class="form-control" required>
	<br>
    </div>
    <div class="form-group">
	<input type="text" name="hcust_contact" placeholder="Customer phone number" class="form-control" required>
	<br>
    </div>
	<input type="submit" name="hsubmit" value="submit" class="btn btn-primary">
	<input type="reset" value="reset" class="btn btn-primary">
</form>


</div>
  </div>
  </div>
  </div>




<?php
 include("footer.php");
?>
