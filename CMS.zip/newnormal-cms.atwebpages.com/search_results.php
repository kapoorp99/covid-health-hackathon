<?php
ob_start();
include_once("config/connection.php");
$fetchdata=new DB_con;
?>

<?php
if(!(isset($_SESSION['user_name']) && $_SESSION['user_name']!=""))
{
	include("header.php");
?>

<div>
	<p>Search Results</p>
	<br>
</div>
<hr>


<?php
	 get_results($fetchdata); 
	include("footer.php");

}
else
{
	include("welcome_header.php");
?>


<div>
	<p>Search Results</p>
	<br>
</div>
<hr>


<?php
     get_results($fetchdata);   
     include("welcome_footer.php");
}
?>

<?php
function get_results($fetchdata)
{
	if(isset($_GET['sq']))
	{
	$x=$_GET['sq'];
	$shopstatus_sql="SELECT * FROM shop_status WHERE shop_id='$x'; ";
	$data1=mysqli_query($fetchdata->con,$shopstatus_sql);
	$info1=mysqli_fetch_assoc($data1);


	$results_arr1=array("status"=>$info1['status']);

	$shopinfo_sql="SELECT * FROM shop WHERE shop_id='$x'; ";
	$data2=mysqli_query($fetchdata->con,$shopinfo_sql);
	$info2=mysqli_fetch_assoc($data2);
	$nor=mysqli_num_rows($data2); //$nor => number of rows found in search results

	$results_arr2=array("id"=>$info2['shop_id'],"owner"=>$info2['shop_owner'],"address"=>$info2['shop_address'],"shop_name"=>$info2['shop_name'],"phone"=>$info2['shop_contact']);



?>




<!-- BEGIN TABLE RESULT -->

<div class="container">

    <hgroup class="mb20">
		<h1>Search Results</h1>
		<h2 class="lead"><strong class="text-danger"><?php echo $nor; ?></strong> results were found</h2>								
	</hgroup>
            <div class="table-responsive">
              <table class="table table-hover">
                <tbody>
                  <tr>
                  <td>1</td>
                  <td><img src="https://via.placeholder.com/120x100" alt=""></td>
                  <td><strong><?php echo $results_arr2['shop_name']; ?></strong><br>This is the shop description.</td>
                  <td><span><i class="fa fa-phone" aria-hidden="true"></i><?php echo " ".$results_arr2['phone']; ?></span></td>
                  <td><?php echo $results_arr1['status']; ?></td>
                  <?php
                  if(!(isset($_SESSION['user_name']) && $_SESSION['user_name']!=""))
                  {
                  ?>
                  <td>Login to follow</td>
                  <?php
                  }
                  else
                  {
                  ?>
                  <td>
                  	<?php 

                  		$temp_cid=$_SESSION['login_u_id'];
                  		$temp_sid=$_GET['sq'];
                  		$caf_sql="SELECT * FROM customer_follows WHERE cust_id='$temp_cid' AND shop_id='$temp_sid' ";//$caf=>check already followed
                  	    $exe_caf_sql=mysqli_query($fetchdata->con,$caf_sql);
                  	    
                  		?>
                  	<form action="" method="POST"> 

                      <input type="submit" name="follow" class="btn btn-primary" value="Follow" <?php if(mysqli_num_rows($exe_caf_sql)==1)
                  	    { ?>disabled<?php } ?> > 
                      <input type="submit" name="unfollow" class="btn btn-primary" value="Unfollow" <?php if(mysqli_num_rows($exe_caf_sql)==0)
                  	    { ?>disabled<?php } ?> > 

                    </form> 
                  </td>
                  <?php
                  //here in this else part customer is logged in ,so just we have to give him follow or unfollow option

                  //-------------------------------------------------------------------------------------
                  if(isset($_POST['follow']))
                  { 

                   $usertype=$_SESSION['u_type']; 
                   $logid=$_SESSION['login_u_id'];
                   $sid=$results_arr2['id'];
                   $cid=$logid;

                   if($usertype == "customer")
                   {

                   //------customer-------------------------------------------------------------------------------
                     //check for same entry in the db
                        //$cfseocts => check for same entry of customer_id to shop_id
                   	//---------------------------------------------------------
                   	     $flag="not_give_access_to_follow";
                   	     $cfseocts_sql="SELECT * FROM customer_follows WHERE shop_id='$sid' AND cust_id='$cid' ";
                   	     $exe_cfseocts_sql=mysqli_query($fetchdata->con,$cfseocts_sql);
                   	     if(mysqli_num_rows($exe_cfseocts_sql)==0)
                   	     {
                   	     	$flag="give_access_to_follow";
                   	     }
                    //---------------------------------------------------------

                      if($flag=="give_access_to_follow")
                      {
                      	$follow_sql="INSERT INTO customer_follows (shop_id,cust_id) VALUES ('$sid','$cid') ";
                      	$exe_follow_sql=mysqli_query($fetchdata->con,$follow_sql);
                      	if($exe_follow_sql)
                      	{
                      		echo "you have started following this shop.";
                      		header('location:search_results.php?sq='.$_GET['sq']);
                      	}
                      	else
                      	{
                      		echo "you cannot follow this shop.";
                      	}
                       }

                  //------customer-----------------------------------------------------------------------------------
                   }
                   else
                   {
                   	echo "For following or unfollowing the shops you have to be a customer.";
                   }

                  } 
                  //--------------------------------------------------------------------------------------
                    if(isset($_POST['unfollow']))
                  	{ 
                   		
                   		$usertype=$_SESSION['u_type']; 
                   		$logid=$_SESSION['login_u_id'];
                   		$sid=$results_arr2['id'];
                   		$cid=$logid;

                   		if($usertype == "customer")
                   		{
                      		$follow_sql="DELETE FROM customer_follows WHERE cust_id='$cid' AND shop_id='$sid' ";
                      		$exe_follow_sql=mysqli_query($fetchdata->con,$follow_sql);
                      		if($exe_follow_sql)
                      		{
                      			echo "you have unfollowed this shop.";
                      			header('location:search_results.php?sq='.$_GET['sq']);
                      		}
                      		else
                      		{
                      			echo "you cannot unfollow this shop.";
                      		}
                   		}
                   		else
                   		{
                   			echo "For following or unfollowing the shops you have to be a customer.";
                   		}

                  	}
                  //--------------------------------------------------------------------------------------

                  }
                  ?>
                  </tr>
                </tbody>
          </table>
            </div>
        </div>
<!-- END TABLE RESULT -->



<?php

	}
}

ob_end_flush();
?>
