<div class="" >
    <div class="container">
      <div class="row">
        <div class="col-md-12 mt-3">
          <p class="text-center">&copy; <?php echo date("Y"); ?> kp99 works All rights reserved. </p>
        </div>
      </div>
    </div>
  </div>

</body>
</html>
<?php ob_end_flush();  ?>