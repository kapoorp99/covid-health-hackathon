<?php 
include_once("config/connection.php");
$fetchdata=new DB_con;
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style_welcome/bootstrap-4.3.1.css" type="text/css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Crowd Management System</title>
</head>
<body>
  <nav class="navbar navbar-dark bg-primary" >
      <div class="container d-flex justify-content-center">
        <a class="navbar-brand" href="#">
        <i class="fa d-inline fa-lg fa-circle-o"></i>
        <b> Crowd Management System</b>
        </a>
      </div>
      </nav>


<div class="" >
    <div class="container">
      <div class="row">
        <div class="p-4 col-md-3">
          <h2 class="mb-4">CMS</h2>
          <p>A system for maintaining social distancing and become a corona warrior.</p>
        </div>
        <div class="p-4 col-md-3">
          <h2 class="mb-4">Mapsite</h2>
          <ul class="list-unstyled"> 
          	<a href="#" class="text-dark">Features</a>
          	<br>
          </ul>
        </div>
        <div class="p-4 col-md-3">
          <h2 class="mb-4">Contact</h2>
          <p> 
              <i class="fa d-inline mr-3 text-muted fa-phone"></i>+91 7522828359 </p>
          <p> 
              <i class="fa d-inline mr-3 text-muted fa-envelope-o"></i>kapoorprakhar99@gmail.com </p>
        </div>
        <div class="p-4 col-md-3">
          <h2 class="mb-4">Subscribe</h2>
          <form>
            <fieldset class="form-group"> <label for="exampleInputEmail1">Get our newsletter</label> <input type="email" class="form-control" placeholder="Enter email"> </fieldset> <button type="submit" class="btn btn-outline-dark">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>





<div class="py-3" >
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center d-md-flex justify-content-between align-items-center">
          <ul class="nav d-flex justify-content-center">
            <li class="nav-item"> <a class="nav-link active" href="index.php">Home</a> </li>
            <li class="nav-item"> <a class="nav-link" href="#">Features</a> </li>
          </ul>
          <p class="mb-0 py-1">&copy; <?php echo date("Y"); ?> kp99 works All rights reserved</p>
        </div>
      </div>
    </div>
  </div>
</body>
</html>


