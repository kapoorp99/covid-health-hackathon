<?php
ob_start();
include_once("config/connection.php");
$fetchdata=new DB_con;
$temp_u_type=$_SESSION['u_type'];
if( isset($_POST['update']) && $temp_u_type=="customer")
{
	$cup_name=$_POST['name'];
	$cup_contact=$_POST['contact'];
	$cup_email=$_POST['email'];
	$cup_old_pass=$_POST['old_pass'];
	$cup_new_pass=$_POST['new_pass'];
	$cup_confirm_pass=$_POST['conf_pass'];
	$cid=$_SESSION['login_u_id'];

	$up_cinfo_sql="UPDATE customer SET c_name='$cup_name',c_pass='$cup_confirm_pass',c_contact='$cup_contact',c_email='$cup_email' WHERE c_id='$cid' ";
	$exe_up_cinfo_sql=mysqli_query($fetchdata->con,$up_cinfo_sql);
	if($exe_up_cinfo_sql)
	{
		$_SESSION['user_name']=$cup_name;
		header('location:user_profile.php');
	}
	else
	{
		echo "error".mysqli_error($fetchdata->con);
	}
	
}
if( isset($_POST['update']) && $temp_u_type=="shopkeeper")
{
	$sup_name=$_POST['name'];
	$sup_contact=$_POST['contact'];
	$sup_email=$_POST['email'];
	$sup_old_pass=$_POST['old_pass'];
	$sup_new_pass=$_POST['new_pass'];
	$sup_confirm_pass=$_POST['conf_pass'];
	$sid=$_SESSION['login_u_id'];
	$up_sinfo_sql="UPDATE shop SET shop_owner='$sup_name',shop_password='$sup_confirm_pass',shop_owner_email='$sup_email',shop_contact='$sup_contact' WHERE shop_id='$sid' ";
	$exe_up_sinfo_sql=mysqli_query($fetchdata->con,$up_sinfo_sql);
	if($exe_up_sinfo_sql)
	{
		$_SESSION['user_name']=$sup_name;
                header('location:user_profile.php');
	}
	else
	{
		echo "error".mysqli_error($fetchdata->con);
	}
}
ob_end_flush();
?>