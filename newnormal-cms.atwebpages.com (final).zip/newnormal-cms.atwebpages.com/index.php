<?php
include("header.php");
?>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript" src="javascript/shop_search.js"></script>
     <div class="py-5 text-center" >
    <div class="container">
      <div class="row">
        <div class="mx-auto col-lg-6">
          <h1> Search shops near you</h1>
          <p class="mb-4">Just enter the shop id and click the search button.</p>
          <form class="form-inline d-flex justify-content-center">
            <div class="input-group"> 
            	<input type="text" class="form-control form-control-lg" placeholder="Enter shop id" id="query">
            <div class="input-group-append">
                 <button class="btn btn-primary" type="button" onclick="noqs()">search</button>
            </div>
            </div>
          </form>
          <p class="small">Enter the shop id only otherwise it shows wrong results.</p>
        </div>
      </div>
    </div>
  </div>
<div id="results_tab"></div>
<?php
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true)
{
header('location:welcome.php');
}
include("footer.php");
?>
