<?php
include("welcome_header.php");
$fetchdata=new DB_con;
$temp_uid_soc=$_SESSION['login_u_id']; //temporary storage of user id of shopkeeper or customer 
 $img_src_sql = "SELECT image FROM images WHERE uid='$temp_uid_soc' ";
 $exe_img_src_sql = mysqli_query($fetchdata->con,$img_src_sql);
 $res_exe_img_src_sql = mysqli_fetch_array($exe_img_src_sql);
 $image_src = $res_exe_img_src_sql['image'];


 //----------Fetch all the data of user-----------//
 if($_SESSION['u_type']=="customer")
 {
 $user_all_data_sql="SELECT * FROM customer WHERE c_id='$temp_uid_soc' ";
 $exe_user_all_data_sql=mysqli_query($fetchdata->con,$user_all_data_sql);
 $res_user_all_data_sql=mysqli_fetch_assoc($exe_user_all_data_sql);


 ?>

  <br>

<div class="container">
<div class="row flex-lg-nowrap">
  

  <div class="col">
    <div class="row">
      <div class="col mb-3">
        <div class="card">
          <div class="card-body">
            <div class="e-profile">
              <div class="row">
                <div class="col-12 col-sm-auto mb-3">
                  <div class="mx-auto" style="width: 140px;">
                    <div class="d-flex justify-content-center align-items-center rounded" style="height: 140px; background-color: rgb(233, 236, 239);">
                      <span style="color: rgb(166, 168, 170); font: bold 8pt Arial;"><img src='<?php echo $image_src; ?>' alt="user picture" height="140" width="140"></span>
                    </div>
                  </div>
                </div>
                <div class="col d-flex flex-column flex-sm-row justify-content-between mb-3">
                  <div class="text-center text-sm-left mb-2 mb-sm-0">
                    <h4 class="pt-sm-2 pb-1 mb-0 text-nowrap"><?php echo $_SESSION['user_name']; ?></h4>
                    <p class="mb-0">@ <?php echo $_SESSION['login_u_id']; ?></p>
                    <div class="text-muted"><small>Last seen 2 hours ago</small></div>
                    <div class="mt-2">
                      <button class="btn btn-primary" type="button">
                        <i class="fa fa-fw fa-camera"></i>
                        <span>Change Photo</span>
                      </button>
                    </div>
                  </div>
                  <div class="text-center text-sm-right">
                    <span class="badge badge-secondary"><?php echo $_SESSION['u_type']; ?></span>
                    <div class="text-muted"><small>Joined 12 May 2020</small></div>
                  </div>
                </div>
              </div>
              <ul class="nav nav-tabs">
                <li class="nav-item"><a href="" class="active nav-link">Settings</a></li>
              </ul>
              <div class="tab-content pt-3">
                <div class="tab-pane active">


                  <!------------------------------------------------------>
                  <!-- Update form start---------------------------------->

                  <form action="update_profile.php" class="form" method="POST">
                    <div class="row">
                      <div class="col">
                        <div class="row">
                          <div class="col">
                            <div class="form-group">
                              <label>Full Name</label>
                              <input class="form-control" type="text" name="name" value="<?php echo $_SESSION['user_name']; ?>">
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col">
                            <div class="form-group">
                              <label>Email</label>
                              <input class="form-control" type="email" name="email" value="<?php echo $res_user_all_data_sql['c_email']; ?>">
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col">
                            <div class="form-group">
                              <label>Contact Number</label>
                              <input class="form-control" type="text" name="contact" value="<?php echo $res_user_all_data_sql['c_contact']; ?>">
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-12 col-sm-6 mb-3">
                        <div class="mb-2"><b>Change Password</b></div>
                        <div class="row">
                          <div class="col">
                            <div class="form-group">
                              <label>Current Password</label>
                              <input class="form-control" type="password" name="old_pass" value="<?php echo $res_user_all_data_sql['c_pass']; ?>">
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col">
                            <div class="form-group">
                              <label>New Password</label>
                              <input class="form-control" type="password" name="new_pass" value="<?php echo $res_user_all_data_sql['c_pass']; ?>">
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col">
                            <div class="form-group">
                              <label>Confirm <span class="d-none d-xl-inline">Password</span></label>
                              <input class="form-control" type="password" name="conf_pass" value="<?php echo $res_user_all_data_sql['c_pass']; ?>"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col d-flex justify-content-end">
                        <input type="submit" class="btn btn-primary" name="update" value="Save Changes">
                      </div>
                    </div>
                  </form>

                 <!-- Update form end------------------------->

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-12 col-md-2 mb-3">
      
        <div class="card">
          <div class="card-body">
            <h6 class="card-title font-weight-bold">Need Help</h6>
            <p class="card-text">Get fast, free help from our friendly assistants.</p>
            <button type="button" class="btn btn-primary">Contact Us</button>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>
</div>




<?php

}
else
{
  $user_all_data_sql="SELECT * FROM shop WHERE shop_id='$temp_uid_soc' ";
  $exe_user_all_data_sql=mysqli_query($fetchdata->con,$user_all_data_sql);
  $res_user_all_data_sql=mysqli_fetch_assoc($exe_user_all_data_sql);


?>


    <br>

<div class="container">
<div class="row flex-lg-nowrap">
  

  <div class="col">
    <div class="row">
      <div class="col mb-3">
        <div class="card">
          <div class="card-body">
            <div class="e-profile">
              <div class="row">
                <div class="col-12 col-sm-auto mb-3">
                  <div class="mx-auto" style="width: 140px;">
                    <div class="d-flex justify-content-center align-items-center rounded" style="height: 140px; background-color: rgb(233, 236, 239);">
                      <span style="color: rgb(166, 168, 170); font: bold 8pt Arial;"><img src='<?php echo $image_src; ?>' alt="user picture" height="140" width="140"></span>
                    </div>
                  </div>
                </div>
                <div class="col d-flex flex-column flex-sm-row justify-content-between mb-3">
                  <div class="text-center text-sm-left mb-2 mb-sm-0">
                    <h4 class="pt-sm-2 pb-1 mb-0 text-nowrap"><?php echo $_SESSION['user_name']; ?></h4>
                    <p class="mb-0">@ <?php echo $_SESSION['login_u_id']; ?></p>
                    <div class="text-muted"><small>Last seen 2 hours ago</small></div>
                    <div class="mt-2">
                      <button class="btn btn-primary" type="button">
                        <i class="fa fa-fw fa-camera"></i>
                        <span>Change Photo</span>
                      </button>
                    </div>
                  </div>
                  <div class="text-center text-sm-right">
                    <span class="badge badge-secondary"><?php echo $_SESSION['u_type']; ?></span>
                    <div class="text-muted"><small>Joined 12 May 2020</small></div>
                  </div>
                </div>
              </div>
              <ul class="nav nav-tabs">
                <li class="nav-item"><a href="" class="active nav-link">Settings</a></li>
              </ul>
              <div class="tab-content pt-3">
                <div class="tab-pane active">

                  <!------------------------------------------------------>
                  <!-- Update form start---------------------------------->

                  <form action="update_profile.php" class="form" method="POST">
                    <div class="row">
                      <div class="col">
                        <div class="row">
                          <div class="col">
                            <div class="form-group">
                              <label>Full Name</label>
                              <input class="form-control" type="text" name="name" value="<?php echo $_SESSION['user_name']; ?>">
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col">
                            <div class="form-group">
                              <label>Email</label>
                              <input class="form-control" type="email" name="email" value="<?php echo $res_user_all_data_sql['shop_owner_email']; ?>">
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col">
                            <div class="form-group">
                              <label>Contact Number</label>
                              <input class="form-control" type="text" name="contact" value="<?php echo $res_user_all_data_sql['shop_contact']; ?>">
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-12 col-sm-6 mb-3">
                        <div class="mb-2"><b>Change Password</b></div>
                        <div class="row">
                          <div class="col">
                            <div class="form-group">
                              <label>Current Password</label>
                              <input class="form-control" type="password" name="old_pass" value="<?php echo $res_user_all_data_sql['shop_password']; ?>">
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col">
                            <div class="form-group">
                              <label>New Password</label>
                              <input class="form-control" type="password" name="new_pass" value="<?php echo $res_user_all_data_sql['shop_password']; ?>">
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col">
                            <div class="form-group">
                              <label>Confirm <span class="d-none d-xl-inline">Password</span></label>
                              <input class="form-control" type="password" name="conf_pass" value="<?php echo $res_user_all_data_sql['shop_password']; ?>"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col d-flex justify-content-end">
                        <input type="submit" class="btn btn-primary" name="update" value="Save Changes">
                      </div>
                    </div>
                  </form>

                 <!-- Update form end------------------------->

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-12 col-md-2 mb-3">
      
        <div class="card">
          <div class="card-body">
            <h6 class="card-title font-weight-bold">Need Help</h6>
            <p class="card-text">Get fast, free help from our friendly assistants.</p>
            <button type="button" class="btn btn-primary">Contact Us</button>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>
</div>

<?php

}

?>

<?php
include("welcome_footer.php");
?>