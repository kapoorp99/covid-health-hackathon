<?php 
include_once("config/connection.php");
$fetchdata=new DB_con;
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true)
{
    header('location:welcome.php');
}
?>
<?php
 include("header.php");
 ?>

<div class="container bg-info">
<p class="font-weight-bold">
<?php
if(isset($_POST['hsubmit']))
{
	$sname=$_POST['hshop_name'];
	$saddress=$_POST['hshop_address'];
	$spass=$_POST['hshop_password'];
	$scontact=$_POST['hshop_contact'];
	$sowner=$_POST['hshop_owner'];
	$semail=$_POST['hshop_email'];
	$isql="INSERT INTO shop (shop_name,shop_address,shop_password,shop_contact,shop_owner,shop_owner_email) VALUES ('$sname','$saddress','$spass','$scontact','$sowner','$semail')";
	$d=mysqli_query($fetchdata->con,$isql);
	if($d)
	{
		echo "Data inserted successfully.";
		$data=mysqli_query($fetchdata->con,"SELECT * FROM shop WHERE shop_id=(last_insert_id())"); //last inserted shop id
        $result=mysqli_fetch_assoc($data);
        $temp=$result['shop_id'];
        echo " Your login ID: ".$temp;
        $isql_status="INSERT INTO shop_status (shop_id) VALUES ('$temp') ";
        $data=mysqli_query($fetchdata->con,$isql_status);
        $icassql="INSERT INTO customer_at_shop (shop_id) VALUES ('$temp') ";
        $data=mysqli_query($fetchdata->con,$icassql);
	}
	else
	{
		echo "Failed insertion".mysqli_error($fetchdata->con);
	}
}
?>
</p>
</div>

<div class="py-5 text-center" style="" >
    <div class="container">
      <div class="row">
        <div class="mx-auto col-md-6 col-10 bg-white p-5">
   <h1 class="mb-4">Register shop</h1>
<form action="" method="post">
	<div class="form-group">
	<input type="text" name="hshop_name" placeholder="Shop Name" class="form-control" required>
	<br>
    </div>
    <div class="form-group mb-3">
	<input type="text" name="hshop_address" placeholder="Shop address" class="form-control" required>
	<br>
    </div>
    <div class="form-group mb-3">
	<input type="password" name="hshop_password" placeholder="Shop password" class="form-control" required>
	<br>
    </div>
    <div class="form-group mb-3">
	<input type="tel" name="hshop_contact" placeholder="Shopkeeper phone number" class="form-control" required>
	<br>
    </div>
	<div class="form-group mb-3">
	<input type="text" name="hshop_owner" placeholder="Shop Owner Name" class="form-control" required>
	<br>
    </div>
    <div class="form-group mb-3">
	<input type="email" name="hshop_email" placeholder="Owner email" class="form-control" required>
	<br>
    </div>
	<input type="submit" name="hsubmit" value="submit" class="btn btn-primary">
	<input type="reset" value="reset" class="btn btn-primary">
</form>


  </div>
  </div>
  </div>
  </div>







<?php
 include("footer.php");
?>