<?php
include("welcome_header.php");
$fetchdata=new DB_con;
if(isset($_POST['but_upload'])){
 
  $name = $_FILES['file']['name'];
  $target_dir = "uploaded_images/";
  $target_file = $target_dir . basename($_FILES["file"]["name"]);

  // Select file type
  $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

  // Valid file extensions
  $extensions_arr = array("jpg","jpeg","png");

  // Check extension
  if( in_array($imageFileType,$extensions_arr) ){
 
    // Convert to base64 
    $image_base64 = base64_encode(file_get_contents($_FILES['file']['tmp_name']) );
    $image = 'data:image/'.$imageFileType.';base64,'.$image_base64;
    // Insert record
    $query = "INSERT INTO images(image) values('".$image."')";
    mysqli_query($fetchdata->con,$query);
  
    // Upload file
    move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$name);
  }
 
}
?>

<form method="post" action="" enctype='multipart/form-data'>
  <input type='file' name='file' />
  <input type='submit' value='Save name' name='but_upload'>
</form>

<?php

 $sql = "SELECT image FROM images WHERE id=1";
 $result = mysqli_query($fetchdata->con,$sql);
 $row = mysqli_fetch_array($result);

 $image_src = $row['image'];
 
?>
<img src='<?php echo $image_src; ?>'alt="hello" >



<?php include("welcome_footer.php"); ?>