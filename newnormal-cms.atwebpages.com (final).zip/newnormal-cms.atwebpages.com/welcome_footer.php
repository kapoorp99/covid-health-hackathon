
<?php
if(!(isset($_SESSION['user_name']) && $_SESSION['user_name']!=""))
{
  header('location:login.php');
}
?>
<div class="py-3" >
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center d-md-flex justify-content-between align-items-center">
          <ul class="nav d-flex justify-content-center">
            <li class="nav-item"> <a class="nav-link active" href="index.php">Home</a> </li>
            <li class="nav-item"> <a class="nav-link" href="#">Features</a> </li>
            <li class="nav-item"> <a class="nav-link" href="aboutus.php">About Us</a> </li>
          </ul>
          <p class="mb-0 py-1">&copy; <?php echo date("Y"); ?> kp99 works All rights reserved</p>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
<?php ob_end_flush();  ?>